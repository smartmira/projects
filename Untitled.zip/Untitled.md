### lets create a model using the U.S. Home Sales dataset

### problem definition
in this project i am trying to predict the value of each house based on the category

### data
we were able to get our data from Tableau Public Data Sets,the link below is the location of the U.S. Home Sales dataset
https://public.tableau.com/app/learn/sample-data


```python
#lets import all the tools needed
import pandas as pd
import numpy as np
import sklearn
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import make_scorer
from sklearn.impute import KNNImputer
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import RandomizedSearchCV
 from sklearn.model_selection import cross_val_score
from sklearn.metrics import mean_absolute_error, r2_score, mean_squared_log_error
```


      Cell In[133], line 13
        from sklearn.model_selection import cross_val_score
        ^
    IndentationError: unexpected indent
    



```python
#import the dataset and assign it to house_sales
house_sales = pd.read_csv(r"C:\Users\USER\Desktop\house_price\house_sales.csv", encoding='latin1')
```

### lets do a little visualization to understand the dataset


```python
house_sales.head()
```


```python
#length of our dataset
len(house_sales)
```


```python
house_sales.info()
```

### lets view each column and see how they correspond with each other to better understand our dataset


```python
#lets check out our category columns
house_sales.groupby(['cat_idx', 'cat_code', 'cat_desc', 'cat_indent']).size()
```


```python
# plot a graph to visualize all our category columns using groupby
grouped_data = house_sales.groupby(['cat_idx', 'cat_code', 'cat_desc']).size().reset_index(name='count')

# Plotting
plt.figure(figsize=(12, 6))
sns.barplot(data=grouped_data, x='cat_code', y='count', hue='cat_desc')
plt.title('Counts of House Sales by Category')
plt.xlabel('Category Code')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.legend(title='Category Description')
plt.tight_layout()
plt.show()
```


```python
#lets check out our data column
house_sales.groupby(['dt_idx', 'dt_code', 'dt_desc', 'dt_unit']).size()
```


```python
# plot a graph to visualize all our data columns using groupby
grouped_data_dt = house_sales.groupby(['dt_idx', 'dt_code', 'dt_desc', 'dt_unit']).size().reset_index(name='count')

plt.figure(figsize=(12, 6))
sns.barplot(data=grouped_data_dt, x='dt_code', y='count', hue='dt_unit')
plt.title('Counts of House Sales by data')
plt.xlabel('dta Code')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.legend(title='data Description')
#plt.tight_layout()
plt.show()

```


```python
# this tells us the estimated values on how accurate the actual values recorded on our dataset is
# the values on our estimate column seems to be really poor  
# as we know higher values indicate higer errors on our dataset but we can fix that
house_sales.groupby(['et_idx', 'et_code', 'et_desc', 'et_unit']).size()
```


```python
# plot a graph to visualize all our error term columns using groupby
grouped_data_dt = house_sales.groupby(['et_idx', 'et_code', 'et_desc', 'et_unit']).size().reset_index(name='count')

plt.figure(figsize=(12, 6))
sns.barplot(data=grouped_data_dt, x='et_code', y='et_idx', hue='et_desc')
plt.title('Counts of House Sales by data')
plt.xlabel('et_Code')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.legend(title='errortotal Description')
#plt.tight_layout()
plt.show()
```


```python
# lets check out our geographical column
house_sales.groupby(['geo_code', 'geo_desc', 'geo_idx']).size()
```


```python
# plot a graph to visualize all our geographical columns using groupby
group_data_geo = house_sales.groupby(['geo_code', 'geo_desc', 'geo_idx']).size().reset_index(name='count')

plt.figure(figsize=(12, 6))
sns.barplot(data=group_data_geo, x='geo_code', y='count', hue='geo_desc')
plt.xlabel('geo_Code')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.legend(title='geo_loc')
#plt.tight_layout()
plt.show()
```


```python
# the is_adjusted columns tells us the columns in our dataset that were adjusted
# 0 means not adjusted 1 means is adjusted
house_sales["is_adj"].value_counts()
```


```python
# this tells us how the cat, data_desc, data_unit and val correspond with eachother
house_sales.groupby(['cat_code', 'dt_desc', 'dt_unit', 'val']).size()
```


```python
# this tells us how the geo_desc, cat_code, data_desc and data_unit correspond with eachother
house_sales.groupby(['geo_desc', 'cat_code', 'dt_desc', 'dt_unit']).size()
```


```python
# one more visualization on our cat and dt_desc columns this tells us how the column performs on count plot
plt.subplot(2, 2, 1)
sns.countplot(y='cat_desc', data=house_sales)
plt.title('category description count')

plt.subplot(2, 2, 4)
sns.countplot(y='dt_desc', data=house_sales)
plt.title('data description count')
```

### lets better understand our val (target) column


```python
house_sales['val'].describe()
```




    count     18610.000000
    mean       9352.033638
    std       42851.074035
    min           1.000000
    25%          11.000000
    50%          31.500000
    75%         151.750000
    max      384000.000000
    Name: val, dtype: float64




```python
#tells us the count for each unique numerical feature on our datset
house_sales['val'].nunique()
```




    1739




```python
#the first plot tells the val dist on its count and its values the y axis are the unique count and the x axis are the values  
plt.figure(figsize=(16, 10))
plt.subplot(2, 2, 1)
sns.histplot(house_sales['val'], bins=30, kde=True)
plt.title('Distribution of val')

# the per name column stands for the date column, this tells our val column overtime we would visualize this after weve wored on our datetime obj
plt.subplot(2, 2, 2)
plt.plot(house_sales['per_name'], house_sales['val'])
plt.xticks(rotation=90)
plt.title('val over time')

plt.tight_layout()
plt.show()
```


    
![png](output_24_0.png)
    


### lets copy our dataset so we can ma some changes on it


```python
df_house = house_sales.copy()
```


```python
df_house.head(1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>per_idx</th>
      <th>per_name</th>
      <th>cat_idx</th>
      <th>cat_code</th>
      <th>cat_desc</th>
      <th>cat_indent</th>
      <th>dt_idx</th>
      <th>dt_code</th>
      <th>dt_desc</th>
      <th>dt_unit</th>
      <th>et_idx</th>
      <th>et_code</th>
      <th>et_desc</th>
      <th>et_unit</th>
      <th>geo_idx</th>
      <th>geo_code</th>
      <th>geo_desc</th>
      <th>is_adj</th>
      <th>val</th>
      <th>serialid</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1/1/1963</td>
      <td>1</td>
      <td>SOLD</td>
      <td>New Single-family Houses Sold</td>
      <td>0</td>
      <td>5</td>
      <td>MEDIAN</td>
      <td>Median Sales Price</td>
      <td>DOL</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>US</td>
      <td>United States</td>
      <td>0</td>
      <td>17200.0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



### rename our per_name column to date 
### change it to a date time object
### plot the val/date column again
### create a year/month/day column from our date column 
### then drop the date column


```python
df_house = df_house.rename(columns = {'per_name': 'date'})
```


```python
df_house['date'] = pd.to_datetime(df_house['date'])
```


```python
plt.subplot(2, 1, 2)
plt.plot(df_house['date'], house_sales['val'])
plt.xticks(rotation=90)
plt.title('val over time')

plt.tight_layout()
plt.show()
```


    
![png](output_31_0.png)
    



```python
date_index = df_house.columns.get_loc('date')
```


```python
df_house.insert(date_index, 'year', df_house['date'].dt.year)
df_house.insert(date_index + 1, 'month', df_house['date'].dt.month)
df_house.insert(date_index + 2, 'day', df_house['date'].dt.day)
```


```python
df_house = df_house.drop('date', axis=1)
```


```python
df_house.head(1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>per_idx</th>
      <th>year</th>
      <th>month</th>
      <th>day</th>
      <th>cat_idx</th>
      <th>cat_code</th>
      <th>cat_desc</th>
      <th>cat_indent</th>
      <th>dt_idx</th>
      <th>dt_code</th>
      <th>...</th>
      <th>et_idx</th>
      <th>et_code</th>
      <th>et_desc</th>
      <th>et_unit</th>
      <th>geo_idx</th>
      <th>geo_code</th>
      <th>geo_desc</th>
      <th>is_adj</th>
      <th>val</th>
      <th>serialid</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1963</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>SOLD</td>
      <td>New Single-family Houses Sold</td>
      <td>0</td>
      <td>5</td>
      <td>MEDIAN</td>
      <td>...</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>US</td>
      <td>United States</td>
      <td>0</td>
      <td>17200.0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>1 rows × 22 columns</p>
</div>



### lets change categorical features to numerical and fill in missing values using KNN


```python
df_house.isna().sum()
```




    per_idx           0
    year              0
    month             0
    day               0
    cat_idx           0
    cat_code          0
    cat_desc          0
    cat_indent        0
    dt_idx            0
    dt_code        5050
    dt_desc        5050
    dt_unit        5050
    et_idx            0
    et_code       15354
    et_desc       15354
    et_unit       15354
    geo_idx           0
    geo_code          0
    geo_desc          0
    is_adj            0
    val            1794
    serialid          0
    dtype: int64




```python
obj = df_house.select_dtypes(exclude=['number']).columns
obj
```




    Index(['cat_code', 'cat_desc', 'dt_code', 'dt_desc', 'dt_unit', 'et_code',
           'et_desc', 'et_unit', 'geo_code', 'geo_desc'],
          dtype='object')




```python
cat_columns = ['cat_code', 'cat_desc', 'dt_code', 'dt_desc', 'dt_unit', 'et_code',
               'et_desc', 'et_unit', 'geo_code', 'geo_desc']
df_house[cat_columns] = df_house[cat_columns].astype('category')
```


```python
df_house.cat_code.cat.codes
```




    0        2
    1        2
    2        2
    3        2
    4        2
            ..
    20399    1
    20400    1
    20401    1
    20402    1
    20403    1
    Length: 20404, dtype: int8




```python
for label, content in df_house.items():
    df_house[label] = pd.Categorical(content).codes+1
```


```python
Imputer = KNNImputer(n_neighbors=5)

df1_house = pd.DataFrame(Imputer.fit_transform(df_house), columns=df_house.columns)
```


```python
df1_house.isna().sum()
```




    per_idx       0
    year          0
    month         0
    day           0
    cat_idx       0
    cat_code      0
    cat_desc      0
    cat_indent    0
    dt_idx        0
    dt_code       0
    dt_desc       0
    dt_unit       0
    et_idx        0
    et_code       0
    et_desc       0
    et_unit       0
    geo_idx       0
    geo_code      0
    geo_desc      0
    is_adj        0
    val           0
    serialid      0
    dtype: int64



### lets create our feature and target variable and create our train test and val split


```python

def rmsle(y_true, y_preds):
    """
    Calculate the Root Mean Squared Log Error (RMSLE).
    """
    return np.sqrt(mean_squared_log_error(y_true, y_preds))

def evaluate_preds(y_true, y_preds):
    """
    Performs evaluation comparison on y_true labels vs. y_pred labels
    on a regression task.
    """
    # Calculate the regression metrics
    mae = mean_absolute_error(y_true, y_preds)
    rmsle_value = rmsle(y_true, y_preds)
    r2 = r2_score(y_true, y_preds)
    
    # Create a dictionary for the metrics
    metric_dict = {"MAE": round(mae, 2),
                   "RMSLE": round(rmsle_value, 2),
                   "R2": round(r2, 2)}
    
    # Print the metrics
    print(f"Mean Absolute Error (MAE): {mae:.2f}")
    print(f"Root Mean Squared Log Error (RMSLE): {rmsle_value:.2f}")
    print(f"R2 Score: {r2:.2f}")
    
    return metric_dict


```


```python
df2_house = df_house.sample(frac=1)

X = df_house.drop('val', axis=1)
y = df_house['val']

train_split = round(0.6 * len (df2_house))
valid_split = round(train_split + 0.2 * len (df2_house))

X_train, y_train = X[:train_split], y[:train_split]
X_val, y_val = X[train_split:valid_split], y[train_split:valid_split]
X_test, y_test = X[valid_split:], y[valid_split:]

X_train.shape, X_val.shape, X_test.shape
```




    ((12242, 21), (4081, 21), (4081, 21))



### lets try a our baseline model to try our split


```python
clf = RandomForestRegressor()
```


```python
clf.fit(X_train, y_train)
```




<style>#sk-container-id-5 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-5 {
  color: var(--sklearn-color-text);
}

#sk-container-id-5 pre {
  padding: 0;
}

#sk-container-id-5 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-5 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-5 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-5 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-5 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-5 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-5 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-5 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-5 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-5 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-5 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-5 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-5 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-5 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-5 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-5 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-5 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-5 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-5 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-5 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-5 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-5 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-5 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-5 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-5 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-5 div.sk-label label.sk-toggleable__label,
#sk-container-id-5 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-5 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-5 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-5 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-5 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-5 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-5 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-5 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-5 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-5 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-5 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-5 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-5 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-5" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestRegressor()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-9" type="checkbox" checked><label for="sk-estimator-id-9" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;RandomForestRegressor<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.ensemble.RandomForestRegressor.html">?<span>Documentation for RandomForestRegressor</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>RandomForestRegressor()</pre></div> </div></div></div></div>




```python
y_preds = clf.predict(X_val)

baseline_metrics = evaluate_preds(y_val, y_preds)
baseline_metrics
```

    Mean Absolute Error (MAE): 25.21
    Root Mean Squared Log Error (RMSLE): 0.39
    R2 Score: 0.96
    




    {'MAE': 25.21, 'RMSLE': 0.39, 'R2': 0.96}



### works well now lets check other models to see which works best


```python
models = {"Linear": LinearRegression(),
          "Random": RandomForestRegressor(),
          "Gradient": GradientBoostingRegressor()
         }

def fit_and_score(models, X_train, y_train, X_val, y_val):
    np.random.seed(42)
    model_scores = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        model_scores[name] = model.score(X_val, y_val)

    return model_scores
```


```python
model_scores = fit_and_score(models=models,
                             X_train=X_train,
                             y_train=y_train,
                             X_val=X_val,
                             y_val=y_val)
model_scores
```




    {'Linear': 0.7756945294279587,
     'Random': 0.9641076446560166,
     'Gradient': 0.957085905005262}




```python
model_compare = pd.DataFrame(model_scores, index=["accuracy"])
model_compare.T.plot.bar()
plt.show()
```


    
![png](output_54_0.png)
    


### our RandomForestRegressor still performs best now lets try hyperparameter tunning to see if we can improve on it


```python
rf_grid = {"n_estimators": np.arange(10, 100, 10),
           "max_depth": [None, 3, 5, 10],
           "min_samples_split": np.arange(2, 20, 2),
           "min_samples_leaf": np.arange(1, 20, 2),
           "max_features": [0.5, 1, "sqrt", "log2"],
           "max_samples": [None]}
```


```python

rf_model = RandomizedSearchCV(RandomForestRegressor(random_state=42),
                               param_distributions=rf_grid,
                               n_iter=5,
                               cv=5,
                               verbose=True)
rf_model.fit(X_train, y_train)
```

    Fitting 5 folds for each of 5 candidates, totalling 25 fits
    




<style>#sk-container-id-6 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-6 {
  color: var(--sklearn-color-text);
}

#sk-container-id-6 pre {
  padding: 0;
}

#sk-container-id-6 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-6 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-6 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-6 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-6 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-6 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-6 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-6 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-6 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-6 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-6 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-6 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-6 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-6 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-6 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-6 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-6 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-6 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-6 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-6 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-6 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-6 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-6 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-6 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-6 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-6 div.sk-label label.sk-toggleable__label,
#sk-container-id-6 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-6 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-6 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-6 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-6 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-6 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-6 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-6 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-6 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-6 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-6 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-6 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-6 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-6" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomizedSearchCV(cv=5, estimator=RandomForestRegressor(random_state=42),
                   n_iter=5,
                   param_distributions={&#x27;max_depth&#x27;: [None, 3, 5, 10],
                                        &#x27;max_features&#x27;: [0.5, 1, &#x27;sqrt&#x27;,
                                                         &#x27;log2&#x27;],
                                        &#x27;max_samples&#x27;: [None],
                                        &#x27;min_samples_leaf&#x27;: array([ 1,  3,  5,  7,  9, 11, 13, 15, 17, 19]),
                                        &#x27;min_samples_split&#x27;: array([ 2,  4,  6,  8, 10, 12, 14, 16, 18]),
                                        &#x27;n_estimators&#x27;: array([10, 20, 30, 40, 50, 60, 70, 80, 90])},
                   verbose=True)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-10" type="checkbox" ><label for="sk-estimator-id-10" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;RandomizedSearchCV<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.model_selection.RandomizedSearchCV.html">?<span>Documentation for RandomizedSearchCV</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>RandomizedSearchCV(cv=5, estimator=RandomForestRegressor(random_state=42),
                   n_iter=5,
                   param_distributions={&#x27;max_depth&#x27;: [None, 3, 5, 10],
                                        &#x27;max_features&#x27;: [0.5, 1, &#x27;sqrt&#x27;,
                                                         &#x27;log2&#x27;],
                                        &#x27;max_samples&#x27;: [None],
                                        &#x27;min_samples_leaf&#x27;: array([ 1,  3,  5,  7,  9, 11, 13, 15, 17, 19]),
                                        &#x27;min_samples_split&#x27;: array([ 2,  4,  6,  8, 10, 12, 14, 16, 18]),
                                        &#x27;n_estimators&#x27;: array([10, 20, 30, 40, 50, 60, 70, 80, 90])},
                   verbose=True)</pre></div> </div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-11" type="checkbox" ><label for="sk-estimator-id-11" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">best_estimator_: RandomForestRegressor</label><div class="sk-toggleable__content fitted"><pre>RandomForestRegressor(max_features=1, min_samples_split=12, n_estimators=90,
                      random_state=42)</pre></div> </div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-12" type="checkbox" ><label for="sk-estimator-id-12" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;RandomForestRegressor<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.ensemble.RandomForestRegressor.html">?<span>Documentation for RandomForestRegressor</span></a></label><div class="sk-toggleable__content fitted"><pre>RandomForestRegressor(max_features=1, min_samples_split=12, n_estimators=90,
                      random_state=42)</pre></div> </div></div></div></div></div></div></div></div></div>




```python
rf_model.best_params_
```




    {'n_estimators': 90,
     'min_samples_split': 12,
     'min_samples_leaf': 1,
     'max_samples': None,
     'max_features': 1,
     'max_depth': None}




```python
y_preds1 = rf_model.predict(X_val)
```


```python
def rmsle(y_val, y_preds1):
    return np.sqrt(mean_squared_log_error(y_val, y_preds1))
    

def evaluate_preds(y_val, y_preds1):
    mae = mean_absolute_error(y_val, y_preds1)
    rmsle_value = rmsle(y_val, y_preds1)
    r2 = r2_score(y_val, y_preds1)
    metric_dict={"mae": round(mae, 2),
                 "rmsle": round(rmsle_value, 2),
                 "r2_score": round(r2, 2)}
    
    print(f"mae: {mae:.2f}")
    print(f"rmsle: {rmsle_value:.2f}")
    print(f"r2_score: {r2 * 100:.2f}%")

    return metric_dict
    
```


```python
evaluate_preds(y_val, y_preds1)
```

    mae: 43.14
    rmsle: 1.32
    r2_score: 94.88%
    




    {'mae': 43.14, 'rmsle': 1.32, 'r2_score': 0.95}



### after trying series of hyperparameter tunning, our base model is still the best

## now lets proceed

### trying to understand our score on each evaluation metric


```python
r2_score(y_true=y_val,
         y_pred=y_preds)
```




    0.964199168712523




```python
mae = mean_absolute_error(y_val, y_preds)
mae
```




    25.21297231070816




```python
rmsle = np.sqrt(mean_squared_log_error(y_val, y_preds))
rmsle
```




    0.3892627837261351




```python
df = pd.DataFrame(data={"actual values": y_val,
                        "predicted values": y_preds})

df["differences"] = df["predicted values"] - df["actual values"]
df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>actual values</th>
      <th>predicted values</th>
      <th>differences</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>12242</th>
      <td>1419</td>
      <td>1413.04</td>
      <td>-5.96</td>
    </tr>
    <tr>
      <th>12243</th>
      <td>4</td>
      <td>4.03</td>
      <td>0.03</td>
    </tr>
    <tr>
      <th>12244</th>
      <td>34</td>
      <td>30.73</td>
      <td>-3.27</td>
    </tr>
    <tr>
      <th>12245</th>
      <td>6</td>
      <td>5.99</td>
      <td>-0.01</td>
    </tr>
    <tr>
      <th>12246</th>
      <td>33</td>
      <td>30.77</td>
      <td>-2.23</td>
    </tr>
    <tr>
      <th>12247</th>
      <td>6</td>
      <td>6.19</td>
      <td>0.19</td>
    </tr>
    <tr>
      <th>12248</th>
      <td>21</td>
      <td>23.30</td>
      <td>2.30</td>
    </tr>
    <tr>
      <th>12249</th>
      <td>10</td>
      <td>9.64</td>
      <td>-0.36</td>
    </tr>
    <tr>
      <th>12250</th>
      <td>88</td>
      <td>88.57</td>
      <td>0.57</td>
    </tr>
    <tr>
      <th>12251</th>
      <td>789</td>
      <td>792.17</td>
      <td>3.17</td>
    </tr>
  </tbody>
</table>
</div>



### lets us cross validation to evaluate our scores


```python
np.random.seed(42)
cv_r2 = cross_val_score(clf, X, y, cv=5, scoring=None)
cv_r2
```




    array([0.92360925, 0.97879478, 0.99296204, 0.97322259, 0.99038766])




```python
np.mean(cv_r2)
```




    0.9717952646623337




```python
cv_mae = cross_val_score(clf, X, y, cv=5, scoring="neg_mean_absolute_error")
cv_mae
```




    array([-41.18765009, -23.88468268, -13.74735114, -20.69047782,
           -11.8167451 ])




```python
np.mean(cv_mae)
```




    -22.26538136462132




```python
def rmsle(y_true, y_preds):
    return np.sqrt(mean_squared_log_error(y_true, y_preds))

rmsle_scorer = make_scorer(rmsle, greater_is_better=False)
cv_rmsle = cross_val_score(clf, X, y, cv=5, scoring=rmsle_scorer)
cv_rmsle
```




    array([-0.43076434, -0.32512637, -0.16035403, -0.31433769, -0.23279518])




```python
np.mean(cv_rmsle)
```




    -0.2926755232108603



## lets evaluate our test set


```python
y_preds2 = clf.predict(X_test)
```


```python
evaluate_preds(y_test, y_preds2)
```

    mae: 43.36
    rmsle: 0.62
    r2_score: 91.26%
    




    {'mae': 43.36, 'rmsle': 0.62, 'r2_score': 0.91}



## now lets build our pipeline to do everything at once


```python
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.impute import KNNImputer
from sklearn.ensemble import RandomForestRegressor
import pandas as pd
from sklearn.model_selection import train_test_split
import numpy as np

np.random.seed(42)

# Load the data
data = pd.read_csv(r"C:\Users\USER\Desktop\house_price\house_sales.csv", encoding='latin1')
data.dropna(subset=["val"], inplace=True)

# Define categorical and numerical columns
cat_columns = ['cat_code', 'cat_desc', 'dt_code', 'dt_desc', 'dt_unit', 
               'et_code', 'et_desc', 'et_unit', 'geo_code', 'geo_desc']
specific_columns = ['cat_idx', 'cat_indent', 'dt_idx', 'et_idx', 'geo_idx', 'is_adj', 'serialid']
num_columns = specific_columns 

# Define the transformers
numerical_transformer = Pipeline(steps=[
    ('imputer', KNNImputer(n_neighbors=5))
])

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),  
    ('encoder', OneHotEncoder(handle_unknown='ignore'))
])

# Combine the transformers
preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, num_columns),
        ('cat', categorical_transformer, cat_columns)
    ]
)

# Define the model pipeline
model = Pipeline(steps=[("preprocessor", preprocessor),
                        ("model", RandomForestRegressor())])

# Prepare the data for training
X = data.drop("val", axis=1)
y = data["val"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Fit the model
model.fit(X_train, y_train)

# Evaluate the model
model_score = model.score(X_test, y_test)
print("Model score:", model_score)

```

    Model score: 0.9985234605616489
    


```python
import pickle
filename = 'house_prices'
with open(filename, 'wb') as file:
    pickle.dump(model, file)
```


```python

```


```python

```


```python

```


```python

```
